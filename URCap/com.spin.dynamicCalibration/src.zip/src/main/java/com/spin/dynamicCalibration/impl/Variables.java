package com.spin.dynamicCalibration.impl;

public class Variables {
	public static String IPv4 = "192.168.100.50";
	public static String Port = "50005";
	public static String Message = "Enter a message here";
}
